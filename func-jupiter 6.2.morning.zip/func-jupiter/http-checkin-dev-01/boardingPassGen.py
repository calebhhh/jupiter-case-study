import time
import os
import json
import random
import string
import pickle


def get_boarding_passcode():
    return ''.join(random.choice(string.ascii_uppercase)for i in range(6))

def get_gate_number():
    key = ''
    key = ''.join(random.choice(string.ascii_uppercase)for i in range(2))
    key += key.join(random.choice(string.digits))
    return key

start_time = time.time()

to_send_message_cnt = 5000
bytes_per_message = 256

def generate(length=to_send_message_cnt) -> list:
    boardingpassnumbers=[]
 
    for i in range(length):
        boardingpassnumbers.append(get_boarding_passcode())
    # store the data as binary data stream